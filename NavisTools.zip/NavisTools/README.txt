﻿NAVISTOOLS
Author: Johan Boone, BOOJ5
Email: johan.boone@witteveenbos.com

INSTALLATION INSTRUCTIONS

To install this addin, copy the folder 'NavisTools' to the following directory:
C:\Program Files\Autodesk\Navisworks Manage 20xx\Plugins\

 After this, restart Navisworks.